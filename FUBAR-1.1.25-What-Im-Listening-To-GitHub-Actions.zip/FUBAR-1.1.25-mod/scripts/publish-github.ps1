param(
  [string]$RepositoryName = "fubarzi/fubar",
  [string]$Tag = "v1.1.25-listening-to"
)

$ErrorActionPreference = "Stop"
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$asset = Join-Path $projectRoot "FUBAR-Windows-x64.zip"

if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
  throw "GitHub CLI (gh) is not installed"
}

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
  throw "Git is not installed"
}

gh auth status
if ($LASTEXITCODE -ne 0) {
  throw "GitHub CLI is not authenticated. Run: gh auth login"
}

& (Join-Path $PSScriptRoot "package.ps1") -Configuration Release
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $asset)) {
  throw "Release package build failed"
}

Push-Location $projectRoot
try {
  $remoteExists = git remote get-url origin 2>$null
  if (-not $remoteExists) {
    git init
    git branch -M main
    git add .
    git commit -m "Add What I'm Listening To field"
    gh repo create $RepositoryName --public --source . --remote origin --push `
      --description "Native Windows VOX audio monitor and recorder with stereo, channel splitting, and VB-CABLE support."
    if ($LASTEXITCODE -ne 0) { throw "GitHub repository creation failed" }
  } else {
    git add .
    git commit -m "Add What I'm Listening To field" 2>$null
    git push -u origin main
    if ($LASTEXITCODE -ne 0) { throw "Source push failed" }
  }

  $tagExists = git tag -l $Tag
  if (-not $tagExists) {
    git tag $Tag
  }
  git push origin $Tag
  if ($LASTEXITCODE -ne 0) { throw "Tag push failed" }

  $prevError = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  gh release view $Tag --repo $RepositoryName *> $null
  $releaseExists = $LASTEXITCODE -eq 0
  $ErrorActionPreference = $prevError
  if ($releaseExists) {
    gh release upload $Tag $asset --repo $RepositoryName --clobber
  } else {
    gh release create $Tag $asset --repo $RepositoryName --title "FUBAR $Tag" --notes-file CHANGELOG.md
  }
  if ($LASTEXITCODE -ne 0) { throw "GitHub release publication failed" }

  gh repo view $RepositoryName --web
} finally {
  Pop-Location
}
