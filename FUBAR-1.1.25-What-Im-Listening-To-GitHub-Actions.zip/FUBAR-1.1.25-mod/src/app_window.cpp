#include "app_window.h"

#include "app_paths.h"
#include "audio_safety.h"
#include "../resources/resource.h"

#include <commctrl.h>
#include <mmsystem.h>
#include <shellapi.h>
#include <shobjidl.h>

#include <algorithm>
#include <chrono>
#include <cstring>
#include <cwctype>
#include <filesystem>
#include <iomanip>
#include <memory>
#include <sstream>
#include <string>
#include <utility>

namespace {

constexpr wchar_t kMainClass[] = L"FubarMainWindow";
constexpr wchar_t kReplayClass[] = L"FubarReplayWindow";
constexpr wchar_t kBrandClass[] = L"FubarRotatedBrand";
constexpr UINT kMessageStatus = WM_APP + 1;
constexpr UINT kMessageReplay = WM_APP + 2;
constexpr UINT_PTR kMeterTimer = 1;

template <typename T>
class LocalComPtr {
 public:
  ~LocalComPtr() { reset(); }
  T* operator->() const { return value_; }
  T** put() {
    reset();
    return &value_;
  }
  void reset() {
    if (value_) value_->Release();
    value_ = nullptr;
  }

 private:
  T* value_ = nullptr;
};

enum ControlId {
  IdDevice = 100,
  IdMode,
  IdThreshold,
  IdFrequency,
  IdPreRoll,
  IdHold,
  IdSave,
  IdMonitor,
  IdForce,
  IdAppend,
  IdSplit,
  IdOutput,
  IdBrowse,
  IdStart,
  IdStop,
  IdReplay,
  IdOpenFolder,
  IdReplayList,
  IdReplayPlay,
  IdReplayOpen,
  IdRefreshDevices,
  IdWeb,
  IdOpenWeb,
  IdCopyWeb,
  IdPublic,
  IdStationName,
  IdListeningTo,
  IdSaveListeningTo
};

HWND addControl(HWND parent, const wchar_t* className, const wchar_t* text, DWORD style,
                int x, int y, int width, int height, int id = 0,
                DWORD extendedStyle = 0) {
  HWND control = CreateWindowExW(extendedStyle, className, text, WS_CHILD | WS_VISIBLE | style,
                                 x, y, width, height, parent,
                                 reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),
                                 GetModuleHandleW(nullptr), nullptr);
  SendMessageW(control, WM_SETFONT, reinterpret_cast<WPARAM>(GetStockObject(DEFAULT_GUI_FONT)),
               TRUE);
  return control;
}

std::string wideToUtf8(const std::wstring& value) {
  if (value.empty()) return {};
  const int bytes = WideCharToMultiByte(CP_UTF8, 0, value.c_str(), static_cast<int>(value.size()),
                                        nullptr, 0, nullptr, nullptr);
  std::string out(static_cast<std::size_t>(bytes), '\0');
  WideCharToMultiByte(CP_UTF8, 0, value.c_str(), static_cast<int>(value.size()), out.data(), bytes,
                      nullptr, nullptr);
  return out;
}

std::wstring utf8ToWideLocal(const std::string& value) {
  if (value.empty()) return {};
  const int chars = MultiByteToWideChar(CP_UTF8, 0, value.c_str(), static_cast<int>(value.size()),
                                        nullptr, 0);
  std::wstring out(static_cast<std::size_t>(chars), L'\0');
  MultiByteToWideChar(CP_UTF8, 0, value.c_str(), static_cast<int>(value.size()), out.data(), chars);
  return out;
}

std::wstring windowText(HWND control) {
  const int length = GetWindowTextLengthW(control);
  std::wstring value(static_cast<std::size_t>(length), L'\0');
  if (length > 0) GetWindowTextW(control, value.data(), length + 1);
  return value;
}

void setWindowNumber(HWND control, double value, int precision = 1) {
  std::wostringstream stream;
  stream << std::fixed << std::setprecision(precision) << value;
  SetWindowTextW(control, stream.str().c_str());
}

int meterPosition(float db) {
  return static_cast<int>(std::clamp(db + 90.0f, 0.0f, 90.0f) * 10.0f);
}

std::wstring dbLabel(float db) {
  std::wostringstream stream;
  stream << std::fixed << std::setprecision(1) << db << L" dB";
  return stream.str();
}

bool likelyPhysicalInput(const std::wstring& name) {
  std::wstring lower = name;
  std::transform(lower.begin(), lower.end(), lower.begin(),
                 [](wchar_t value) { return static_cast<wchar_t>(std::towlower(value)); });
  return lower.find(L"cable") == std::wstring::npos &&
         lower.find(L"virtual") == std::wstring::npos &&
         lower.find(L"stereo mix") == std::wstring::npos;
}

LRESULT CALLBACK brandProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
  if (message != WM_PAINT) return DefWindowProcW(window, message, wParam, lParam);
  PAINTSTRUCT paint{};
  HDC deviceContext = BeginPaint(window, &paint);
  RECT bounds{};
  GetClientRect(window, &bounds);
  FillRect(deviceContext, &bounds, reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1));
  SetGraphicsMode(deviceContext, GM_ADVANCED);
  XFORM rotation{-1.0f, 0.0f, 0.0f, -1.0f,
                 static_cast<FLOAT>(bounds.right), static_cast<FLOAT>(bounds.bottom)};
  SetWorldTransform(deviceContext, &rotation);
  LOGFONTW font{};
  font.lfHeight = -28;
  font.lfWeight = FW_BLACK;
  wcscpy_s(font.lfFaceName, LF_FACESIZE, L"Segoe UI");
  HFONT brandFont = CreateFontIndirectW(&font);
  HGDIOBJ previousFont = SelectObject(deviceContext, brandFont);
  SetBkMode(deviceContext, TRANSPARENT);
  SetTextColor(deviceContext, RGB(25, 25, 25));
  DrawTextW(deviceContext, L"FUBAR", -1, &bounds,
            DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);
  SelectObject(deviceContext, previousFont);
  DeleteObject(brandFont);
  EndPaint(window, &paint);
  return 0;
}

std::wstring replayLabel(const ReplayEntry& entry) {
  const std::time_t time = std::chrono::system_clock::to_time_t(entry.started);
  std::tm local{};
  localtime_s(&local, &time);
  std::wostringstream stream;
  stream << std::put_time(&local, L"%Y-%m-%d %H:%M:%S") << L"  "
         << std::fixed << std::setprecision(2) << entry.frequencyMhz << L" MHz  "
         << channelModeName(entry.mode) << L"  " << std::setprecision(1)
         << entry.durationSeconds << L" s  " << entry.peakDb << L" dB  "
         << entry.path.filename().wstring();
  return stream.str();
}

}  // namespace

AppWindow::AppWindow(AudioOptions initialOptions, std::uint16_t webPort)
    : options_(std::move(initialOptions)), cliWebPort_(webPort) {
  autoSelectInput_ = options_.deviceId.empty() && options_.deviceName.empty();
}

int AppWindow::run(HINSTANCE instance, int showCommand) {
  instance_ = instance;
  INITCOMMONCONTROLSEX controls{sizeof(controls), ICC_PROGRESS_CLASS | ICC_BAR_CLASSES};
  InitCommonControlsEx(&controls);

  WNDCLASSEXW mainClass{};
  mainClass.cbSize = sizeof(mainClass);
  mainClass.lpfnWndProc = windowProc;
  mainClass.hInstance = instance_;
  mainClass.hCursor = LoadCursorW(nullptr, IDC_ARROW);
  mainClass.hIcon = LoadIconW(instance_, MAKEINTRESOURCEW(IDI_APPICON));
  mainClass.hIconSm = reinterpret_cast<HICON>(LoadImageW(
      instance_, MAKEINTRESOURCEW(IDI_APPICON), IMAGE_ICON,
      GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0));
  if (!mainClass.hIcon) {
    mainClass.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
  }
  if (!mainClass.hIconSm) {
    mainClass.hIconSm = mainClass.hIcon;
  }
  mainClass.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
  mainClass.lpszClassName = kMainClass;
  RegisterClassExW(&mainClass);

  WNDCLASSEXW replayClass{};
  replayClass.cbSize = sizeof(replayClass);
  replayClass.lpfnWndProc = replayProc;
  replayClass.hInstance = instance_;
  replayClass.hCursor = LoadCursorW(nullptr, IDC_ARROW);
  replayClass.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
  replayClass.lpszClassName = kReplayClass;
  RegisterClassExW(&replayClass);

  WNDCLASSEXW brandClass{};
  brandClass.cbSize = sizeof(brandClass);
  brandClass.lpfnWndProc = brandProc;
  brandClass.hInstance = instance_;
  brandClass.hCursor = LoadCursorW(nullptr, IDC_ARROW);
  brandClass.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
  brandClass.lpszClassName = kBrandClass;
  RegisterClassExW(&brandClass);

  HMENU menu = LoadMenuW(instance_, MAKEINTRESOURCEW(IDR_MAINMENU));
  window_ = CreateWindowExW(0, kMainClass, L"FUBAR VOX V1.1.25", WS_OVERLAPPEDWINDOW,
                            CW_USEDEFAULT, CW_USEDEFAULT, 780, 875, nullptr, menu, instance_,
                            this);
  if (!window_) return 1;
  ShowWindow(window_, showCommand);
  UpdateWindow(window_);

  MSG message{};
  while (GetMessageW(&message, nullptr, 0, 0) > 0) {
    TranslateMessage(&message);
    DispatchMessageW(&message);
  }
  return static_cast<int>(message.wParam);
}

LRESULT CALLBACK AppWindow::windowProc(HWND window, UINT message, WPARAM wParam,
                                       LPARAM lParam) {
  AppWindow* app = reinterpret_cast<AppWindow*>(GetWindowLongPtrW(window, GWLP_USERDATA));
  if (message == WM_NCCREATE) {
    const auto* create = reinterpret_cast<CREATESTRUCTW*>(lParam);
    app = static_cast<AppWindow*>(create->lpCreateParams);
    app->window_ = window;
    SetWindowLongPtrW(window, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(app));
  }
  return app ? app->handleMessage(window, message, wParam, lParam)
             : DefWindowProcW(window, message, wParam, lParam);
}

LRESULT CALLBACK AppWindow::replayProc(HWND window, UINT message, WPARAM wParam,
                                       LPARAM lParam) {
  AppWindow* app = reinterpret_cast<AppWindow*>(GetWindowLongPtrW(window, GWLP_USERDATA));
  if (message == WM_NCCREATE) {
    const auto* create = reinterpret_cast<CREATESTRUCTW*>(lParam);
    app = static_cast<AppWindow*>(create->lpCreateParams);
    SetWindowLongPtrW(window, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(app));
  }
  return app ? app->handleReplayMessage(window, message, wParam, lParam)
             : DefWindowProcW(window, message, wParam, lParam);
}

LRESULT AppWindow::handleMessage(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
  switch (message) {
    case WM_CREATE:
      idleStatusBrush_ = CreateSolidBrush(RGB(190, 35, 35));
      recordingStatusBrush_ = CreateSolidBrush(RGB(25, 150, 70));
      createControls();
      loadSettings();
      if (cliWebPort_) webPort_ = cliWebPort_;
      refreshWebCheckLabel();
      populateDevices();
      applyOptionsToControls();
      reloadCapturesFromDisk();
      pruneOldRecordings();
      applyWebServer();
      SetTimer(window, kMeterTimer, 75, nullptr);
      PostMessageW(window, WM_COMMAND, IdStart, 0);
      return 0;

    case WM_CTLCOLORSTATIC:
      if (reinterpret_cast<HWND>(lParam) == statusLabel_) {
        HDC deviceContext = reinterpret_cast<HDC>(wParam);
        SetTextColor(deviceContext, RGB(255, 255, 255));
        SetBkColor(deviceContext,
                   statusRecording_ ? RGB(25, 150, 70) : RGB(190, 35, 35));
        return reinterpret_cast<LRESULT>(statusRecording_ ? recordingStatusBrush_
                                                          : idleStatusBrush_);
      }
      break;

    case WM_COMMAND:
      switch (LOWORD(wParam)) {
        case IdStart: startEngine(); return 0;
        case IdStop: stopEngine(); return 0;
        case IdRefreshDevices: refreshDevices(); return 0;
        case IdBrowse: browseOutputDirectory(); return 0;
        case IdOpenFolder: openOutputDirectory(); return 0;
        case IdReplay: showReplayWindow(); return 0;
        case IdOpenWeb: openWebsite(); return 0;
        case IdCopyWeb: copyWebsiteUrl(); return 0;
        case IdSaveListeningTo:
          saveSettings();
          return 0;
        case ID_TOOLS_SETTINGS: showSettings(); return 0;
        case ID_TOOLS_RECORDINGS: showRecordings(); return 0;
        case IdWeb:
          if (HIWORD(wParam) == BN_CLICKED) {
            webEnabled_ = SendMessageW(webCheck_, BM_GETCHECK, 0, 0) == BST_CHECKED;
            if (!webEnabled_) publicServer_ = false;
            if (publicCheck_) {
              SendMessageW(publicCheck_, BM_SETCHECK, publicServer_ ? BST_CHECKED : BST_UNCHECKED, 0);
            }
            applyWebServer();
            applyPublicListing();
            saveSettings();
          }
          return 0;
        case IdPublic:
          if (HIWORD(wParam) == BN_CLICKED) {
            publicServer_ = SendMessageW(publicCheck_, BM_GETCHECK, 0, 0) == BST_CHECKED;
            if (publicServer_ && !webEnabled_) {
              webEnabled_ = true;
              if (webCheck_) SendMessageW(webCheck_, BM_SETCHECK, BST_CHECKED, 0);
              applyWebServer();
            }
            applyPublicListing();
            saveSettings();
          }
          return 0;
        case IdStationName:
          if (HIWORD(wParam) == EN_KILLFOCUS) {
            stationName_ = windowText(stationEdit_);
            applyPublicListing();
            saveSettings();
          }
          return 0;
        case IdDevice:
          if (HIWORD(wParam) == CBN_SELCHANGE) {
            autoSelectInput_ = false;
            probedDeviceIds_.clear();
            startEngine();
          }
          return 0;
        case IdMode:
          if (HIWORD(wParam) == CBN_SELCHANGE) startEngine();
          return 0;
        case IdSave:
        case IdMonitor:
        case IdForce:
        case IdAppend:
        case IdSplit:
          if (HIWORD(wParam) == BN_CLICKED) startEngine();
          return 0;
      }
      break;

    case WM_HSCROLL:
      if (reinterpret_cast<HWND>(lParam) == thresholdSlider_) {
        const int value = static_cast<int>(SendMessageW(thresholdSlider_, TBM_GETPOS, 0, 0));
        const std::wstring label = std::to_wstring(value) + L" dB";
        SetWindowTextW(thresholdValue_, label.c_str());
      }
      return 0;

    case WM_TIMER:
      if (wParam == kMeterTimer) updateMeters();
      return 0;

    case kMessageStatus: {
      std::unique_ptr<std::wstring> status(reinterpret_cast<std::wstring*>(lParam));
      if (status) updateStatus(*status);
      return 0;
    }

    case kMessageReplay: {
      std::unique_ptr<ReplayEntry> replay(reinterpret_cast<ReplayEntry*>(lParam));
      if (replay) {
        auto existing = std::find_if(replays_.begin(), replays_.end(),
                                     [&](const ReplayEntry& item) { return item.path == replay->path; });
        if (existing != replays_.end()) *existing = *replay;
        else replays_.push_back(*replay);
        refreshReplayWindow();
      }
      return 0;
    }

    case WM_CLOSE:
      saveSettings();
      applyPublicListing();
      netClient_.stop();
      if (!stationId_.empty()) web_.unpublishStation(stationId_);
      stopEngine();
      web_.stop();
      DestroyWindow(window);
      return 0;

    case WM_DESTROY:
      KillTimer(window, kMeterTimer);
      if (idleStatusBrush_) DeleteObject(idleStatusBrush_);
      if (recordingStatusBrush_) DeleteObject(recordingStatusBrush_);
      idleStatusBrush_ = nullptr;
      recordingStatusBrush_ = nullptr;
      PostQuitMessage(0);
      return 0;
  }
  return DefWindowProcW(window, message, wParam, lParam);
}

void AppWindow::createControls() {
  addControl(window_, kBrandClass, L"", WS_BORDER, 20, 18, 120, 48);
  statusLabel_ = addControl(window_, L"STATIC", L"Idle", SS_CENTER | SS_CENTERIMAGE | WS_BORDER, 150, 18, 590, 48);
  addControl(window_, L"STATIC", L"What I'm Listening To:", SS_RIGHT, 20, 78, 175, 24);
  listeningToEdit_ = addControl(window_, L"EDIT", L"", WS_BORDER | ES_AUTOHSCROLL, 205, 75, 425, 27,
                                IdListeningTo, WS_EX_CLIENTEDGE);
  addControl(window_, L"BUTTON", L"Save", BS_PUSHBUTTON, 640, 75, 80, 27,
             IdSaveListeningTo);

  addControl(window_, L"BUTTON", L"Audio source and VOX settings", BS_GROUPBOX, 20, 115, 720, 275);
  addControl(window_, L"STATIC", L"Audio input device:", SS_RIGHT, 40, 145, 160, 22);
  deviceCombo_ = addControl(window_, L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_VSCROLL, 210, 141, 410, 240, IdDevice);
  addControl(window_, L"BUTTON", L"Refresh", BS_PUSHBUTTON, 630, 140, 80, 27,
             IdRefreshDevices);
  addControl(window_, L"STATIC", L"Input channel:", SS_RIGHT, 40, 180, 160, 22);
  modeCombo_ = addControl(window_, L"COMBOBOX", L"", CBS_DROPDOWNLIST, 210, 176, 220, 160,
                          IdMode);
  addControl(window_, L"STATIC", L"Trigger threshold:", SS_RIGHT, 40, 215, 160, 22);
  thresholdSlider_ = addControl(window_, TRACKBAR_CLASSW, L"", TBS_AUTOTICKS, 210, 207, 400, 35, IdThreshold);
  SendMessageW(thresholdSlider_, TBM_SETRANGE, TRUE, MAKELONG(-60, -5));
  thresholdValue_ = addControl(window_, L"STATIC", L"-35 dB", SS_CENTER, 620, 215, 80, 22);
  addControl(window_, L"STATIC", L"Radio frequency (MHz):", SS_RIGHT, 40, 252, 160, 22);
  frequencyEdit_ = addControl(window_, L"EDIT", L"268.000", WS_BORDER | ES_AUTOHSCROLL, 210, 248, 110, 24, IdFrequency, WS_EX_CLIENTEDGE);
  addControl(window_, L"STATIC", L"Pre-roll (sec):", SS_RIGHT, 335, 252, 100, 22);
  preRollEdit_ = addControl(window_, L"EDIT", L"1.0", WS_BORDER | ES_AUTOHSCROLL, 445, 248, 70, 24, IdPreRoll, WS_EX_CLIENTEDGE);
  addControl(window_, L"STATIC", L"Hold (sec):", SS_RIGHT, 525, 252, 75, 22);
  holdEdit_ = addControl(window_, L"EDIT", L"1.5", WS_BORDER | ES_AUTOHSCROLL, 610, 248, 70, 24, IdHold, WS_EX_CLIENTEDGE);
  saveCheck_ = addControl(window_, L"BUTTON", L"Save audio files", BS_AUTOCHECKBOX, 210, 285, 150, 24, IdSave);
  monitorCheck_ = addControl(window_, L"BUTTON", L"Live monitor", BS_AUTOCHECKBOX, 370, 285, 130, 24, IdMonitor);
  forceCheck_ = addControl(window_, L"BUTTON", L"Continuous record", BS_AUTOCHECKBOX, 510, 285, 160, 24, IdForce);
  appendCheck_ = addControl(window_, L"BUTTON", L"Append VOX to one file", BS_AUTOCHECKBOX, 210, 313, 210, 24, IdAppend);
  splitCheck_ = addControl(window_, L"BUTTON", L"Split stereo into L/R files",
                           BS_AUTOCHECKBOX, 435, 313, 235, 24, IdSplit);
  addControl(window_, L"STATIC", L"Recording folder:", SS_RIGHT, 40, 353, 160, 22);
  outputEdit_ = addControl(window_, L"EDIT", defaultCaptureDirectory().wstring().c_str(), WS_BORDER | ES_AUTOHSCROLL, 210, 349, 410, 25, IdOutput, WS_EX_CLIENTEDGE);
  addControl(window_, L"BUTTON", L"Browse...", BS_PUSHBUTTON, 630, 348, 80, 27, IdBrowse);

  addControl(window_, L"BUTTON", L"Live levels — input and routed output", BS_GROUPBOX, 20, 402, 720, 190);
  addControl(window_, L"STATIC", L"Input left", SS_RIGHT, 45, 436, 100, 22);
  inputLeftMeter_ = addControl(window_, PROGRESS_CLASSW, L"", PBS_SMOOTH, 160, 434, 480, 22);
  inputLeftValue_ = addControl(window_, L"STATIC", L"-90.0 dB", SS_RIGHT, 650, 436, 65, 22);
  addControl(window_, L"STATIC", L"Input right", SS_RIGHT, 45, 471, 100, 22);
  inputRightMeter_ = addControl(window_, PROGRESS_CLASSW, L"", PBS_SMOOTH, 160, 469, 480, 22);
  inputRightValue_ = addControl(window_, L"STATIC", L"-90.0 dB", SS_RIGHT, 650, 471, 65, 22);
  addControl(window_, L"STATIC", L"Output left", SS_RIGHT, 45, 520, 100, 22);
  outputLeftMeter_ = addControl(window_, PROGRESS_CLASSW, L"", PBS_SMOOTH, 160, 518, 480, 22);
  outputLeftValue_ = addControl(window_, L"STATIC", L"-90.0 dB", SS_RIGHT, 650, 520, 65, 22);
  addControl(window_, L"STATIC", L"Output right", SS_RIGHT, 45, 555, 100, 22);
  outputRightMeter_ = addControl(window_, PROGRESS_CLASSW, L"", PBS_SMOOTH, 160, 553, 480, 22);
  outputRightValue_ = addControl(window_, L"STATIC", L"-90.0 dB", SS_RIGHT, 650, 555, 65, 22);
  for (HWND meter : {inputLeftMeter_, inputRightMeter_, outputLeftMeter_, outputRightMeter_}) {
    SendMessageW(meter, PBM_SETRANGE32, 0, 900);
    SendMessageW(meter, PBM_SETBARCOLOR, 0, RGB(30, 170, 70));
  }

  startButton_ = addControl(window_, L"BUTTON", L"Apply / Restart", BS_DEFPUSHBUTTON, 85, 612, 130, 38, IdStart);
  stopButton_ = addControl(window_, L"BUTTON", L"Stop", BS_PUSHBUTTON, 230, 612, 100, 38,
                           IdStop);
  addControl(window_, L"BUTTON", L"Replay log", BS_PUSHBUTTON, 345, 612, 130, 38, IdReplay);
  addControl(window_, L"BUTTON", L"Open recordings", BS_PUSHBUTTON, 490, 612, 150, 38,
             IdOpenFolder);
  webCheck_ = addControl(window_, L"BUTTON", L"Public website on port 80", BS_AUTOCHECKBOX, 85, 653, 250, 24, IdWeb);
  addControl(window_, L"BUTTON", L"Open site", BS_PUSHBUTTON, 320, 649, 80, 28, IdOpenWeb);
  addControl(window_, L"BUTTON", L"Copy URL", BS_PUSHBUTTON, 405, 649, 80, 28, IdCopyWeb);
  webStatus_ = addControl(window_, L"STATIC", L"Website off", 0, 569, 616, 230, 24);
  publicCheck_ = addControl(window_, L"BUTTON", L"Public Server", BS_AUTOCHECKBOX, 85, 685, 130, 24, IdPublic);
  addControl(window_, L"STATIC", L"Station name:", SS_RIGHT, 215, 687, 95, 22);
  stationEdit_ = addControl(window_, L"EDIT", L"FUBAR", WS_BORDER | ES_AUTOHSCROLL, 318, 683, 280, 24, IdStationName, WS_EX_CLIENTEDGE);
  addControl(window_, L"STATIC",
             L"Public Server lists this station at https://gearsqueens.online/fubar-net",
              SS_CENTER, 40, 715, 680, 22);
  addControl(window_, L"STATIC",
             L"CLI: FUBAR.exe --cli --headless --web --port 8080 --public-server",
              SS_CENTER, 40, 741, 680, 22);
}

void AppWindow::populateDevices() {
  std::wstring error;
  devices_ = AudioEngine::enumerateInputDevices(&error);
  SendMessageW(deviceCombo_, CB_RESETCONTENT, 0, 0);
  for (const auto& device : devices_) {
    const std::wstring label = device.name + (device.isDefault ? L" (Default input)" : L"");
    SendMessageW(deviceCombo_, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(label.c_str()));
  }
  if (devices_.empty()) {
    SendMessageW(deviceCombo_, CB_ADDSTRING, 0,
                 reinterpret_cast<LPARAM>(L"No active capture devices"));
  }
  SendMessageW(deviceCombo_, CB_SETCURSEL, 0, 0);

  SendMessageW(modeCombo_, CB_RESETCONTENT, 0, 0);
  for (ChannelMode mode : {ChannelMode::Stereo, ChannelMode::Left, ChannelMode::Right,
                           ChannelMode::Mono}) {
    SendMessageW(modeCombo_, CB_ADDSTRING, 0,
                 reinterpret_cast<LPARAM>(channelModeName(mode)));
  }
}

void AppWindow::applyOptionsToControls() {
  int selectedDevice = -1;
  for (std::size_t index = 0; index < devices_.size(); ++index) {
    if ((!options_.deviceId.empty() && devices_[index].id == options_.deviceId) ||
        (!options_.deviceName.empty() && devices_[index].name == options_.deviceName)) {
      selectedDevice = static_cast<int>(index);
      break;
    }
  }
  if (selectedDevice < 0) {
    for (std::size_t index = 0; index < devices_.size(); ++index) {
      if (devices_[index].isDefault) {
        selectedDevice = static_cast<int>(index);
        break;
      }
    }
  }
  if (selectedDevice < 0 && !devices_.empty()) selectedDevice = 0;
  SendMessageW(deviceCombo_, CB_SETCURSEL, selectedDevice, 0);
  SendMessageW(modeCombo_, CB_SETCURSEL, static_cast<int>(options_.mode), 0);
  SendMessageW(thresholdSlider_, TBM_SETPOS, TRUE,
               static_cast<LPARAM>(std::clamp(static_cast<int>(options_.thresholdDb), -60, -5)));
  const std::wstring threshold = std::to_wstring(static_cast<int>(options_.thresholdDb)) + L" dB";
  SetWindowTextW(thresholdValue_, threshold.c_str());
  setWindowNumber(frequencyEdit_, options_.frequencyMhz, 3);
  setWindowNumber(preRollEdit_, options_.preRollSeconds, 1);
  setWindowNumber(holdEdit_, options_.holdSeconds, 1);
  SendMessageW(saveCheck_, BM_SETCHECK, options_.saveAudio ? BST_CHECKED : BST_UNCHECKED, 0);
  SendMessageW(monitorCheck_, BM_SETCHECK, options_.monitor ? BST_CHECKED : BST_UNCHECKED, 0);
  SendMessageW(forceCheck_, BM_SETCHECK, options_.forceRecord ? BST_CHECKED : BST_UNCHECKED, 0);
  SendMessageW(appendCheck_, BM_SETCHECK, options_.appendSession ? BST_CHECKED : BST_UNCHECKED,
               0);
  SendMessageW(splitCheck_, BM_SETCHECK,
               options_.splitStereoFiles ? BST_CHECKED : BST_UNCHECKED, 0);
  SetWindowTextW(outputEdit_, options_.outputDirectory.wstring().c_str());
}

void AppWindow::refreshDevices() {
  options_ = optionsFromControls();
  options_.deviceId.clear();
  options_.deviceName.clear();
  autoSelectInput_ = true;
  probedDeviceIds_.clear();
  populateDevices();
  applyOptionsToControls();
  startEngine();
}

AudioOptions AppWindow::optionsFromControls() const {
  AudioOptions result = options_;
  const int device = static_cast<int>(SendMessageW(deviceCombo_, CB_GETCURSEL, 0, 0));
  if (device >= 0 && device < static_cast<int>(devices_.size())) {
    result.deviceId = devices_[device].id;
    result.deviceName = devices_[device].name;
  }
  const int mode = static_cast<int>(SendMessageW(modeCombo_, CB_GETCURSEL, 0, 0));
  if (mode >= 0 && mode <= 3) result.mode = static_cast<ChannelMode>(mode);
  result.thresholdDb = static_cast<float>(SendMessageW(thresholdSlider_, TBM_GETPOS, 0, 0));
  result.saveAudio = SendMessageW(saveCheck_, BM_GETCHECK, 0, 0) == BST_CHECKED;
  result.monitor = SendMessageW(monitorCheck_, BM_GETCHECK, 0, 0) == BST_CHECKED;
  result.forceRecord = SendMessageW(forceCheck_, BM_GETCHECK, 0, 0) == BST_CHECKED;
  result.appendSession = SendMessageW(appendCheck_, BM_GETCHECK, 0, 0) == BST_CHECKED;
  result.splitStereoFiles = SendMessageW(splitCheck_, BM_GETCHECK, 0, 0) == BST_CHECKED;
  result.outputDirectory = windowText(outputEdit_);
  try { result.frequencyMhz = std::stod(windowText(frequencyEdit_)); } catch (...) {}
  try { result.preRollSeconds = std::stof(windowText(preRollEdit_)); } catch (...) {}
  try { result.holdSeconds = std::stof(windowText(holdEdit_)); } catch (...) {}
  return result;
}

void AppWindow::startEngine() {
  AudioOptions requestedOptions = optionsFromControls();
  saveSettings();
  engine_.stop();
  options_ = std::move(requestedOptions);
  const bool virtualInput = isVirtualAudioEndpoint(options_.deviceName);
  EnableWindow(monitorCheck_, !virtualInput);
  SetWindowTextW(monitorCheck_, virtualInput ? L"Monitor safety lock" : L"Live monitor");
  if (autoSelectInput_) inputProbeStarted_ = std::chrono::steady_clock::now();
  EnableWindow(splitCheck_, options_.mode == ChannelMode::Stereo);
  EnableWindow(appendCheck_, !options_.forceRecord);
  if (isPlaceholderCapturePath(options_.outputDirectory)) {
    options_.outputDirectory = defaultCaptureDirectory();
  }
  std::error_code createError;
  std::filesystem::create_directories(options_.outputDirectory, createError);
  SetWindowTextW(outputEdit_, options_.outputDirectory.wstring().c_str());
  web_.setRoot(options_.outputDirectory);
  web_.setLiveHub(&engine_.liveHub());
  engine_.liveHub().setGainDb(static_cast<float>(liveBoostDb_));
  EnableWindow(startButton_, TRUE);
  EnableWindow(stopButton_, TRUE);
  updateStatus(L"Starting...");
  if (!engine_.start(
      options_,
      [this](const std::wstring& status) {
        if (IsWindow(window_)) {
          PostMessageW(window_, kMessageStatus, 0,
                       reinterpret_cast<LPARAM>(new std::wstring(status)));
        }
      },
      [this](const ReplayEntry& replay) {
        if (IsWindow(window_)) {
          PostMessageW(window_, kMessageReplay, 0,
                       reinterpret_cast<LPARAM>(new ReplayEntry(replay)));
        }
      })) {
    EnableWindow(stopButton_, FALSE);
    updateStatus(engine_.status());
  }
}

void AppWindow::stopEngine() {
  engine_.stop();
  if (startButton_) EnableWindow(startButton_, TRUE);
  if (stopButton_) EnableWindow(stopButton_, FALSE);
  updateStatus(L"Idle");
}

void AppWindow::updateMeters() {
  const auto levels = engine_.levels();
  SendMessageW(inputLeftMeter_, PBM_SETPOS, meterPosition(levels.inputLeftDb), 0);
  SendMessageW(inputRightMeter_, PBM_SETPOS, meterPosition(levels.inputRightDb), 0);
  SendMessageW(outputLeftMeter_, PBM_SETPOS, meterPosition(levels.outputLeftDb), 0);
  SendMessageW(outputRightMeter_, PBM_SETPOS, meterPosition(levels.outputRightDb), 0);
  SetWindowTextW(inputLeftValue_, dbLabel(levels.inputLeftDb).c_str());
  SetWindowTextW(inputRightValue_, dbLabel(levels.inputRightDb).c_str());
  SetWindowTextW(outputLeftValue_, dbLabel(levels.outputLeftDb).c_str());
  SetWindowTextW(outputRightValue_, dbLabel(levels.outputRightDb).c_str());
  if (webEnabled_ && web_.running()) {
    static int webTicks = 0;
    if (++webTicks >= 12) {
      webTicks = 0;
      refreshWebStatus();
      if (publicServer_) {
        const auto station = currentStation();
        web_.publishStation(station);
        netClient_.setPayload(station);
      }
    }
  }
  if (autoSelectInput_ && engine_.running()) {
    if (isVirtualAudioEndpoint(options_.deviceName)) {
      autoSelectInput_ = false;
    }
  }
  if (autoSelectInput_ && engine_.running()) {
    const float inputPeak = std::max(levels.inputLeftDb, levels.inputRightDb);
    if (inputPeak > -89.0f) {
      autoSelectInput_ = false;
      probedDeviceIds_.clear();
    } else if (std::chrono::steady_clock::now() - inputProbeStarted_ >=
               std::chrono::seconds(2)) {
      const int selected = static_cast<int>(SendMessageW(deviceCombo_, CB_GETCURSEL, 0, 0));
      if (selected >= 0 && selected < static_cast<int>(devices_.size())) {
        probedDeviceIds_.push_back(devices_[selected].id);
      }
      int fallback = -1;
      for (std::size_t index = 0; index < devices_.size(); ++index) {
        const bool alreadyProbed =
            std::find(probedDeviceIds_.begin(), probedDeviceIds_.end(), devices_[index].id) !=
            probedDeviceIds_.end();
        if (!alreadyProbed && likelyPhysicalInput(devices_[index].name)) {
          fallback = static_cast<int>(index);
          break;
        }
      }
      if (fallback >= 0) {
        SendMessageW(deviceCombo_, CB_SETCURSEL, fallback, 0);
        startEngine();
        return;
      }
      autoSelectInput_ = false;
      updateStatus(L"NO INPUT SIGNAL — choose another input or check its mute switch");
    }
  }
  if (!engine_.running() && !engine_.status().empty() && engine_.status() != L"Idle") {
    updateStatus(engine_.status());
  }
}

void AppWindow::updateStatus(const std::wstring& status) {
  statusRecording_ = status == L"Recording";
  std::wstring text = status;
  if (status == L"Recording") text = L"● RECORDING — signal above threshold";
  else if (status == L"LISTENING - live monitor disabled for virtual-cable capture safety") {
    text = L"LISTENING — " + options_.deviceName +
           L" — monitor safety lock; capture remains active";
  }
  else if (status.find(L"LISTENING - CABLE WARNING") == 0) {
    text = status;
  }
  else if (status == L"Listening") {
    text = L"LISTENING — " +
           (options_.deviceName.empty() ? std::wstring(L"default input") : options_.deviceName) +
           L" — waiting for VOX trigger";
  }
  else if (status == L"Paused - waiting for audio") {
    text = L"PAUSED — file remains open; waiting to append more audio";
  }
  SetWindowTextW(statusLabel_, text.c_str());
  InvalidateRect(statusLabel_, nullptr, TRUE);
  web_.setLiveStatus(text, statusRecording_);
  web_.setRoot(options_.outputDirectory);
}

void AppWindow::browseOutputDirectory() {
  LocalComPtr<IFileDialog> dialog;
  HRESULT result = CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER,
                                    IID_PPV_ARGS(dialog.put()));
  if (FAILED(result)) return;
  DWORD options = 0;
  dialog->GetOptions(&options);
  dialog->SetOptions(options | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM);
  if (SUCCEEDED(dialog->Show(window_))) {
    LocalComPtr<IShellItem> item;
    if (SUCCEEDED(dialog->GetResult(item.put()))) {
      PWSTR path = nullptr;
      if (SUCCEEDED(item->GetDisplayName(SIGDN_FILESYSPATH, &path))) {
        SetWindowTextW(outputEdit_, path);
        options_.outputDirectory = path;
        CoTaskMemFree(path);
        reloadCapturesFromDisk();
        web_.setRoot(options_.outputDirectory);
      }
    }
  }
}

void AppWindow::openOutputDirectory() const {
  auto path = optionsFromControls().outputDirectory;
  if (path.is_relative()) path = executableDirectory() / path;
  std::error_code error;
  std::filesystem::create_directories(path, error);
  ShellExecuteW(window_, L"open", path.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

void AppWindow::showReplayWindow() {
  if (IsWindow(replayWindow_)) {
    ShowWindow(replayWindow_, SW_SHOW);
    SetForegroundWindow(replayWindow_);
    return;
  }
  replayWindow_ = CreateWindowExW(WS_EX_TOOLWINDOW, kReplayClass, L"FUBAR Replay Log",
                                  WS_OVERLAPPEDWINDOW | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT,
                                  780, 430, window_, nullptr, instance_, this);
}

LRESULT AppWindow::handleReplayMessage(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
  switch (message) {
    case WM_CREATE:
      replayWindow_ = window;
      replayList_ = addControl(window, L"LISTBOX", L"",
                               LBS_NOTIFY | WS_BORDER | WS_VSCROLL | LBS_NOINTEGRALHEIGHT, 15,
                               15, 735, 300, IdReplayList, WS_EX_CLIENTEDGE);
      addControl(window, L"BUTTON", L"Play selected", BS_DEFPUSHBUTTON, 190, 335, 130, 35,
                 IdReplayPlay);
      addControl(window, L"BUTTON", L"Open file location", BS_PUSHBUTTON, 335, 335, 150, 35,
                 IdReplayOpen);
      addControl(window, L"BUTTON", L"Close", BS_PUSHBUTTON, 500, 335, 90, 35, IDCANCEL);
      refreshReplayWindow();
      return 0;
    case WM_COMMAND:
      if (LOWORD(wParam) == IdReplayPlay ||
          (LOWORD(wParam) == IdReplayList && HIWORD(wParam) == LBN_DBLCLK)) {
        playSelectedReplay();
        return 0;
      }
      if (LOWORD(wParam) == IdReplayOpen) {
        const int selected = static_cast<int>(SendMessageW(replayList_, LB_GETCURSEL, 0, 0));
        if (selected >= 0 && selected < static_cast<int>(replays_.size())) {
          const std::wstring parameters = L"/select,\"" + replays_[selected].path.wstring() + L"\"";
          ShellExecuteW(window, L"open", L"explorer.exe", parameters.c_str(), nullptr,
                        SW_SHOWNORMAL);
        }
        return 0;
      }
      if (LOWORD(wParam) == IDCANCEL) {
        DestroyWindow(window);
        return 0;
      }
      break;
    case WM_CLOSE:
      DestroyWindow(window);
      return 0;
    case WM_DESTROY:
      replayWindow_ = nullptr;
      replayList_ = nullptr;
      return 0;
  }
  return DefWindowProcW(window, message, wParam, lParam);
}

void AppWindow::refreshReplayWindow() {
  if (!IsWindow(replayList_)) return;
  SendMessageW(replayList_, LB_RESETCONTENT, 0, 0);
  for (const auto& replay : replays_) {
    const auto label = replayLabel(replay);
    SendMessageW(replayList_, LB_ADDSTRING, 0, reinterpret_cast<LPARAM>(label.c_str()));
  }
  if (!replays_.empty()) {
    SendMessageW(replayList_, LB_SETCURSEL, static_cast<WPARAM>(replays_.size() - 1), 0);
  }
}

void AppWindow::playSelectedReplay() {
  if (!IsWindow(replayList_)) return;
  const int selected = static_cast<int>(SendMessageW(replayList_, LB_GETCURSEL, 0, 0));
  if (selected < 0 || selected >= static_cast<int>(replays_.size())) return;
  PlaySoundW(replays_[selected].path.c_str(), nullptr, SND_FILENAME | SND_ASYNC | SND_NODEFAULT);
}

void AppWindow::saveSettings() const {
  const auto ini = fubarSettingsPath();
  const auto current = optionsFromControls();
  WritePrivateProfileStringW(L"FUBAR", L"OutputDirectory",
                             current.outputDirectory.wstring().c_str(), ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"Frequency",
                             windowText(frequencyEdit_).c_str(), ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"WhatImListeningTo",
                             windowText(listeningToEdit_).c_str(), ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"Threshold",
                             std::to_wstring(static_cast<int>(current.thresholdDb)).c_str(),
                             ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"WebEnabled", webEnabled_ ? L"1" : L"0", ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"WebPort", std::to_wstring(webPort_).c_str(), ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"LiveMaxListeners",
                             std::to_wstring(liveMaxListeners_).c_str(), ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"LiveBoostDb",
                             std::to_wstring(liveBoostDb_).c_str(), ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"PruneDays",
                             std::to_wstring(pruneDays_).c_str(), ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"DeviceId", current.deviceId.c_str(), ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"DeviceName", current.deviceName.c_str(), ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"Mode",
                             std::to_wstring(static_cast<int>(current.mode)).c_str(), ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"PreRoll",
                             windowText(preRollEdit_).c_str(), ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"Hold", windowText(holdEdit_).c_str(), ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"SaveAudio", current.saveAudio ? L"1" : L"0", ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"Monitor", current.monitor ? L"1" : L"0", ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"ForceRecord", current.forceRecord ? L"1" : L"0",
                             ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"AppendSession", current.appendSession ? L"1" : L"0",
                             ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"SplitStereo", current.splitStereoFiles ? L"1" : L"0",
                             ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"PublicServer", publicServer_ ? L"1" : L"0", ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"StationId", utf8ToWideLocal(stationId_).c_str(),
                             ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"StationName",
                             stationEdit_ ? windowText(stationEdit_).c_str() : stationName_.c_str(),
                             ini.c_str());
  WritePrivateProfileStringW(L"FUBAR", L"PublicHost", utf8ToWideLocal(publicHost_).c_str(),
                             ini.c_str());
}

void AppWindow::reloadCapturesFromDisk() {
  if (isPlaceholderCapturePath(options_.outputDirectory)) {
    options_.outputDirectory = defaultCaptureDirectory();
  }
  migrateLegacyCaptures(options_.outputDirectory);
  replays_ = loadCapturesFromDirectory(options_.outputDirectory, options_.frequencyMhz);
  refreshReplayWindow();
  web_.setRoot(options_.outputDirectory);
}

void AppWindow::loadSettings() {
  const auto ini = fubarSettingsPath();
  const auto legacyIni = executableDirectory() / L"FUBAR.ini";
  std::error_code error;
  if (!std::filesystem::exists(ini, error) && std::filesystem::exists(legacyIni, error)) {
    std::filesystem::copy_file(legacyIni, ini, error);
  }
  wchar_t buffer[1024]{};
  if (GetPrivateProfileStringW(L"FUBAR", L"OutputDirectory", L"", buffer, 1024, ini.c_str()) > 0) {
    options_.outputDirectory = buffer;
  }
  if (isPlaceholderCapturePath(options_.outputDirectory)) {
    options_.outputDirectory = defaultCaptureDirectory();
  }
  if (GetPrivateProfileStringW(L"FUBAR", L"Frequency", L"", buffer, 1024, ini.c_str()) > 0) {
    try { options_.frequencyMhz = std::stod(buffer); } catch (...) {}
  }
  if (GetPrivateProfileStringW(L"FUBAR", L"WhatImListeningTo", L"", buffer, 1024, ini.c_str()) > 0) {
    if (listeningToEdit_) SetWindowTextW(listeningToEdit_, buffer);
  }
  if (GetPrivateProfileStringW(L"FUBAR", L"Threshold", L"", buffer, 1024, ini.c_str()) > 0) {
    try { options_.thresholdDb = std::stof(buffer); } catch (...) {}
  }
  webEnabled_ = GetPrivateProfileIntW(L"FUBAR", L"WebEnabled", 0, ini.c_str()) != 0;
  webPort_ = CaptureWebServer::clampPort(
      GetPrivateProfileIntW(L"FUBAR", L"WebPort", 80, ini.c_str()), 80);
  liveMaxListeners_ = LiveSlotGate::clampLimit(
      GetPrivateProfileIntW(L"FUBAR", L"LiveMaxListeners", LiveSlotGate::kDefaultLimit, ini.c_str()));
  liveBoostDb_ = std::clamp(
      static_cast<int>(GetPrivateProfileIntW(L"FUBAR", L"LiveBoostDb", 0, ini.c_str())), 0, 18);
  pruneDays_ = std::clamp(
      static_cast<int>(GetPrivateProfileIntW(L"FUBAR", L"PruneDays", 0, ini.c_str())), 0, 3650);
  if (GetPrivateProfileStringW(L"FUBAR", L"DeviceId", L"", buffer, 1024, ini.c_str()) > 0) {
    options_.deviceId = buffer;
  }
  if (GetPrivateProfileStringW(L"FUBAR", L"DeviceName", L"", buffer, 1024, ini.c_str()) > 0) {
    options_.deviceName = buffer;
  }
  const int mode = GetPrivateProfileIntW(L"FUBAR", L"Mode", static_cast<int>(options_.mode),
                                         ini.c_str());
  if (mode >= 0 && mode <= 3) options_.mode = static_cast<ChannelMode>(mode);
  if (GetPrivateProfileStringW(L"FUBAR", L"PreRoll", L"", buffer, 1024, ini.c_str()) > 0) {
    try { options_.preRollSeconds = std::stof(buffer); } catch (...) {}
  }
  if (GetPrivateProfileStringW(L"FUBAR", L"Hold", L"", buffer, 1024, ini.c_str()) > 0) {
    try { options_.holdSeconds = std::stof(buffer); } catch (...) {}
  }
  options_.saveAudio = GetPrivateProfileIntW(L"FUBAR", L"SaveAudio", 1, ini.c_str()) != 0;
  options_.monitor = GetPrivateProfileIntW(L"FUBAR", L"Monitor", 1, ini.c_str()) != 0;
  options_.forceRecord = GetPrivateProfileIntW(L"FUBAR", L"ForceRecord", 0, ini.c_str()) != 0;
  options_.appendSession = GetPrivateProfileIntW(L"FUBAR", L"AppendSession", 0, ini.c_str()) != 0;
  options_.splitStereoFiles = GetPrivateProfileIntW(L"FUBAR", L"SplitStereo", 0, ini.c_str()) != 0;
  autoSelectInput_ = options_.deviceId.empty() && options_.deviceName.empty();
  if (isVirtualAudioEndpoint(options_.deviceName)) autoSelectInput_ = false;
  if (webCheck_) {
    SendMessageW(webCheck_, BM_SETCHECK, webEnabled_ ? BST_CHECKED : BST_UNCHECKED, 0);
  }
  publicServer_ = GetPrivateProfileIntW(L"FUBAR", L"PublicServer", 0, ini.c_str()) != 0;
  if (GetPrivateProfileStringW(L"FUBAR", L"StationId", L"", buffer, 1024, ini.c_str()) > 0) {
    stationId_ = wideToUtf8(buffer);
  }
  if (stationId_.empty() || !FubarNetDirectory::validStationId(stationId_)) {
    stationId_ = FubarNetDirectory::makeStationId();
  }
  if (GetPrivateProfileStringW(L"FUBAR", L"StationName", L"", buffer, 1024, ini.c_str()) > 0) {
    stationName_ = buffer;
  }
  if (stationName_.empty()) {
    wchar_t computer[MAX_COMPUTERNAME_LENGTH + 1]{};
    DWORD computerSize = MAX_COMPUTERNAME_LENGTH + 1;
    if (GetComputerNameW(computer, &computerSize)) stationName_ = computer;
    else stationName_ = L"FUBAR";
  }
  if (GetPrivateProfileStringW(L"FUBAR", L"PublicHost", L"", buffer, 1024, ini.c_str()) > 0) {
    publicHost_ = FubarNetDirectory::sanitizeHost(wideToUtf8(buffer));
  }
  if (publicCheck_) {
    SendMessageW(publicCheck_, BM_SETCHECK, publicServer_ ? BST_CHECKED : BST_UNCHECKED, 0);
  }
  if (stationEdit_) SetWindowTextW(stationEdit_, stationName_.c_str());
}

void AppWindow::refreshWebStatus() {
  if (!webStatus_) return;
  if (!webEnabled_ || !web_.running()) {
    SetWindowTextW(webStatus_, webEnabled_ ? web_.lastError().c_str() : L"Website off");
    return;
  }
  std::wstring text = L"On air  " + web_.lanUrl() + L"  (" +
                      std::to_wstring(web_.liveListeners()) + L"/" +
                      std::to_wstring(web_.maxLiveListeners()) + L" live";
  if (web_.liveQueued() > 0) {
    text += L", " + std::to_wstring(web_.liveQueued()) + L" waiting";
  }
  text += L")";
  if (publicServer_) {
    const auto listed = netClient_.lastError().empty() ? netClient_.lastOk()
                                                       : netClient_.lastError();
    if (!listed.empty()) text += L"  ·  " + listed;
    else text += L"  ·  listing…";
  }
  SetWindowTextW(webStatus_, text.c_str());
}

void AppWindow::refreshWebCheckLabel() {
  if (!webCheck_) return;
  SetWindowTextW(webCheck_, (L"Public website on port " + std::to_wstring(webPort_)).c_str());
}

void AppWindow::applyWebServer() {
  web_.setLiveHub(&engine_.liveHub());
  web_.setRoot(options_.outputDirectory);
  web_.setMaxLiveListeners(liveMaxListeners_);
  refreshWebCheckLabel();
  if (!webEnabled_) {
    web_.stop();
    refreshWebStatus();
    return;
  }
  if (web_.running() && web_.port() == webPort_) {
    refreshWebStatus();
    return;
  }
  if (web_.running()) web_.stop();
  if (!web_.start(webPort_)) {
    webEnabled_ = false;
    if (webCheck_) SendMessageW(webCheck_, BM_SETCHECK, BST_UNCHECKED, 0);
    refreshWebStatus();
    return;
  }
  refreshWebStatus();
  applyPublicListing();
}

FubarNetStation AppWindow::currentStation() const {
  FubarNetStation station;
  station.id = stationId_;
  std::wstring name = stationEdit_ ? windowText(stationEdit_) : stationName_;
  station.name = FubarNetDirectory::sanitizeName(wideToUtf8(name));
  station.host = publicHost_;
  station.port = web_.port() ? web_.port() : 80;
  station.path = "/";
  station.frequencyMhz = options_.frequencyMhz;
  station.recording = statusRecording_ || engine_.recording();
  station.live = engine_.running();
  station.listeners = web_.liveListeners();
  station.listenerLimit = web_.maxLiveListeners();
  station.version = "1.1.25";
  return station;
}

void AppWindow::applyPublicListing() {
  if (stationEdit_) stationName_ = windowText(stationEdit_);
  if (publicServer_ && web_.running()) {
    const auto station = currentStation();
    web_.publishStation(station);
    netClient_.setPayload(station);
    netClient_.start();
  } else {
    netClient_.stop();
    if (!stationId_.empty()) web_.unpublishStation(stationId_);
  }
}

void AppWindow::openWebsite() const {
  const std::wstring target = web_.running() ? web_.url() : L"http://127.0.0.1/";
  ShellExecuteW(window_, L"open", target.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

void AppWindow::copyWebsiteUrl() const {
  const std::wstring url = web_.running() ? web_.lanUrl() : L"http://127.0.0.1/";
  if (!OpenClipboard(window_)) return;
  EmptyClipboard();
  const SIZE_T bytes = (url.size() + 1) * sizeof(wchar_t);
  HGLOBAL memory = GlobalAlloc(GMEM_MOVEABLE, bytes);
  if (!memory) {
    CloseClipboard();
    return;
  }
  if (void* locked = GlobalLock(memory)) {
    std::memcpy(locked, url.c_str(), bytes);
    GlobalUnlock(memory);
  }
  SetClipboardData(CF_UNICODETEXT, memory);
  CloseClipboard();
  if (webStatus_) SetWindowTextW(webStatus_, (L"Copied  " + url).c_str());
}

void AppWindow::pruneOldRecordings() {
  if (pruneDays_ <= 0) return;
  if (deleteCapturesOlderThan(options_.outputDirectory, pruneDays_) > 0) {
    reloadCapturesFromDisk();
  }
}

namespace {

struct SettingsDialogData {
  int limit = LiveSlotGate::kDefaultLimit;
  int listeners = 0;
  int queued = 0;
  int liveBoostDb = 0;
  int pruneDays = 0;
  int webPort = 80;
  std::wstring publicHost;
};

INT_PTR CALLBACK settingsDialogProc(HWND dialog, UINT message, WPARAM wParam, LPARAM lParam) {
  if (message == WM_INITDIALOG) {
    auto* data = reinterpret_cast<SettingsDialogData*>(lParam);
    SetWindowLongPtrW(dialog, DWLP_USER, reinterpret_cast<LONG_PTR>(data));
    SetDlgItemInt(dialog, IDC_LIVE_LIMIT, static_cast<UINT>(data->limit), FALSE);
    SetDlgItemInt(dialog, IDC_LIVE_BOOST, static_cast<UINT>(data->liveBoostDb), FALSE);
    SetDlgItemInt(dialog, IDC_PRUNE_DAYS, static_cast<UINT>(data->pruneDays), FALSE);
    SetDlgItemInt(dialog, IDC_WEB_PORT, static_cast<UINT>(data->webPort), FALSE);
    SetDlgItemTextW(dialog, IDC_PUBLIC_HOST, data->publicHost.c_str());
    const std::wstring stats = L"Right now: " + std::to_wstring(data->listeners) +
                               L" listening, " + std::to_wstring(data->queued) + L" waiting.";
    SetDlgItemTextW(dialog, IDC_LIVE_STATS, stats.c_str());
    return TRUE;
  }
  if (message == WM_COMMAND) {
    switch (LOWORD(wParam)) {
      case IDOK: {
        auto* data = reinterpret_cast<SettingsDialogData*>(GetWindowLongPtrW(dialog, DWLP_USER));
        BOOL translated = FALSE;
        const int limit = static_cast<int>(GetDlgItemInt(dialog, IDC_LIVE_LIMIT, &translated, FALSE));
        const int boost = static_cast<int>(GetDlgItemInt(dialog, IDC_LIVE_BOOST, &translated, FALSE));
        const int days = static_cast<int>(GetDlgItemInt(dialog, IDC_PRUNE_DAYS, &translated, FALSE));
        const int port = static_cast<int>(GetDlgItemInt(dialog, IDC_WEB_PORT, &translated, FALSE));
        if (data) {
          data->limit = LiveSlotGate::clampLimit(limit);
          data->liveBoostDb = std::clamp(boost, 0, 18);
          data->pruneDays = std::clamp(days, 0, 3650);
          data->webPort = CaptureWebServer::clampPort(port, 80);
          wchar_t host[128]{};
          GetDlgItemTextW(dialog, IDC_PUBLIC_HOST, host, 128);
          data->publicHost = host;
        }
        EndDialog(dialog, IDOK);
        return TRUE;
      }
      case IDCANCEL:
        EndDialog(dialog, IDCANCEL);
        return TRUE;
    }
  }
  return FALSE;
}

struct RecordingsDialogData {
  std::filesystem::path folder;
  double frequencyMhz = 0.0;
  int days = 30;
  std::vector<ReplayEntry> items;
  bool changed = false;
};

std::wstring recordingsLabel(const ReplayEntry& entry) {
  const std::time_t time = std::chrono::system_clock::to_time_t(entry.started);
  std::tm local{};
  localtime_s(&local, &time);
  std::error_code error;
  const auto bytes = std::filesystem::file_size(entry.path, error);
  std::wostringstream stream;
  stream << std::put_time(&local, L"%Y-%m-%d %H:%M:%S") << L"  "
         << std::fixed << std::setprecision(1) << entry.durationSeconds << L" s  "
         << (bytes / 1024) << L" KB  " << entry.path.filename().wstring();
  return stream.str();
}

void fillRecordingsList(HWND dialog, RecordingsDialogData* data) {
  HWND list = GetDlgItem(dialog, IDC_REC_LIST);
  SendMessageW(list, LB_RESETCONTENT, 0, 0);
  data->items = loadCapturesFromDirectory(data->folder, data->frequencyMhz);
  std::reverse(data->items.begin(), data->items.end());
  std::uint64_t bytes = 0;
  for (const auto& item : data->items) {
    std::error_code error;
    bytes += std::filesystem::file_size(item.path, error);
    const auto label = recordingsLabel(item);
    SendMessageW(list, LB_ADDSTRING, 0, reinterpret_cast<LPARAM>(label.c_str()));
  }
  std::wostringstream stats;
  stats << data->items.size() << L" recording" << (data->items.size() == 1 ? L"" : L"s")
        << L"  ·  " << std::fixed << std::setprecision(1)
        << (static_cast<double>(bytes) / (1024.0 * 1024.0)) << L" MB";
  SetDlgItemTextW(dialog, IDC_REC_STATS, stats.str().c_str());
}

INT_PTR CALLBACK recordingsDialogProc(HWND dialog, UINT message, WPARAM wParam, LPARAM lParam) {
  auto* data = reinterpret_cast<RecordingsDialogData*>(GetWindowLongPtrW(dialog, DWLP_USER));
  if (message == WM_INITDIALOG) {
    data = reinterpret_cast<RecordingsDialogData*>(lParam);
    SetWindowLongPtrW(dialog, DWLP_USER, reinterpret_cast<LONG_PTR>(data));
    SetDlgItemInt(dialog, IDC_REC_DAYS, static_cast<UINT>(data->days), FALSE);
    fillRecordingsList(dialog, data);
    return TRUE;
  }
  if (message != WM_COMMAND || !data) return FALSE;
  switch (LOWORD(wParam)) {
    case IDC_REC_REFRESH:
      fillRecordingsList(dialog, data);
      return TRUE;
    case IDC_REC_OPEN:
      ShellExecuteW(dialog, L"open", data->folder.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
      return TRUE;
    case IDC_REC_DELETE: {
      HWND list = GetDlgItem(dialog, IDC_REC_LIST);
      const int count = static_cast<int>(SendMessageW(list, LB_GETSELCOUNT, 0, 0));
      if (count <= 0) return TRUE;
      if (MessageBoxW(dialog, L"Delete the selected recordings? This cannot be undone.",
                      L"Manage recordings", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES) {
        return TRUE;
      }
      std::vector<int> selected(static_cast<std::size_t>(count));
      SendMessageW(list, LB_GETSELITEMS, count, reinterpret_cast<LPARAM>(selected.data()));
      std::vector<std::filesystem::path> paths;
      for (int index : selected) {
        if (index >= 0 && index < static_cast<int>(data->items.size())) {
          paths.push_back(data->items[static_cast<std::size_t>(index)].path);
        }
      }
      PlaySoundW(nullptr, nullptr, SND_PURGE);
      if (deleteCaptureFiles(paths) > 0) data->changed = true;
      fillRecordingsList(dialog, data);
      return TRUE;
    }
    case IDC_REC_DELETE_OLD: {
      BOOL translated = FALSE;
      int days = static_cast<int>(GetDlgItemInt(dialog, IDC_REC_DAYS, &translated, FALSE));
      days = std::clamp(translated ? days : data->days, 1, 3650);
      const std::wstring prompt = L"Delete recordings older than " + std::to_wstring(days) +
                                  L" days? This cannot be undone.";
      if (MessageBoxW(dialog, prompt.c_str(), L"Manage recordings",
                      MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES) {
        return TRUE;
      }
      PlaySoundW(nullptr, nullptr, SND_PURGE);
      if (deleteCapturesOlderThan(data->folder, days) > 0) data->changed = true;
      fillRecordingsList(dialog, data);
      return TRUE;
    }
    case IDCANCEL:
      EndDialog(dialog, IDOK);
      return TRUE;
  }
  return FALSE;
}

}  // namespace

void AppWindow::showSettings() {
  SettingsDialogData data;
  data.limit = liveMaxListeners_;
  data.listeners = web_.liveListeners();
  data.queued = web_.liveQueued();
  data.liveBoostDb = liveBoostDb_;
  data.pruneDays = pruneDays_;
  data.webPort = webPort_;
  data.publicHost = utf8ToWideLocal(publicHost_);
  if (DialogBoxParamW(instance_, MAKEINTRESOURCEW(IDD_SETTINGS), window_, settingsDialogProc,
                      reinterpret_cast<LPARAM>(&data)) != IDOK) {
    return;
  }
  liveMaxListeners_ = LiveSlotGate::clampLimit(data.limit);
  liveBoostDb_ = std::clamp(data.liveBoostDb, 0, 18);
  pruneDays_ = std::clamp(data.pruneDays, 0, 3650);
  webPort_ = CaptureWebServer::clampPort(data.webPort, 80);
  publicHost_ = FubarNetDirectory::sanitizeHost(wideToUtf8(data.publicHost));
  web_.setMaxLiveListeners(liveMaxListeners_);
  engine_.liveHub().setGainDb(static_cast<float>(liveBoostDb_));
  pruneOldRecordings();
  applyWebServer();
  applyPublicListing();
  refreshWebStatus();
  saveSettings();
}

void AppWindow::showRecordings() {
  RecordingsDialogData data;
  data.folder = options_.outputDirectory;
  data.frequencyMhz = options_.frequencyMhz;
  data.days = pruneDays_ > 0 ? pruneDays_ : 30;
  DialogBoxParamW(instance_, MAKEINTRESOURCEW(IDD_RECORDINGS), window_, recordingsDialogProc,
                  reinterpret_cast<LPARAM>(&data));
  if (data.changed) reloadCapturesFromDisk();
}
